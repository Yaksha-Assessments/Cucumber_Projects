package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class VerificationPage_PL2 extends StartupPage {

	public VerificationPage_PL2(WebDriver driver) {
		super(driver);
	}

	/*
	 * --------------------------- Locators
	 * -------------------------------------------
	 */
	
	private By emailInput = By.cssSelector("input#username_id");
	private By passwordInput = By.cssSelector("#password");
	private By signInButton = By.cssSelector("#login");

	public By getInventoryLocator() {
		return By.xpath("//a[@href='#/Inventory']");
	}

	public By getInventoryPageBarFixedLocator(String navBarName) {
		return By.xpath("//ul[contains(@class,'page-breadcrumb')]/li/a[@href='#/Inventory/" + navBarName + "']");
	}

	public By getSubNavTabLocator(String subNavName) {
		return By.xpath("//div[@class=\"sub-navtab\"]/ul/li/a[text()='" + subNavName + "']");
	}

	public By getButtonLocatorsBytext(String buttonName) {
		return By.xpath("//button[contains(text(),'" + buttonName + "')]");
	}

	public By getInputFieldLocator(String inputFieldName) {
		return By.cssSelector("input[display-property-name='" + inputFieldName + "']");
	}

	public By getLocatorById(String idName) {
		return By.id(idName);
	}

	public By getPopUpMessageText(String msgStatus, String messageText) {
		return By.xpath("//p[text()=' " + msgStatus + " ']/../p[contains(@class,'main-message') or contains(text(),'"
				+ messageText + "')]");
	}

	public By getVerificationLocator() {
		return By.xpath("//a[@href='#/Verification']");
	}

	public By getPageBarFixedLocator(String navBarName) {
		return By.xpath("//ul[@class='page-breadcrumb']/li/a[@href='#/Verification/" + navBarName + "']");
	}

	public By getPurchaseRequestStatus(String companyName, String status) {
		return By.xpath("(//div[@col-id='VendorName' and text()='" + companyName
				+ "']/../div[@col-id='VerificationStatus' and text()='" + status + "'])[1]");
	}

	public By getOkButtonLocator() {
		return By.xpath("//button[@class='btn green btn-success']");
	}

	public By getPurchaseRequestViewButton(String status) {
		return By.xpath("(//div[@col-id='VerificationStatus' and text()='" + status
				+ "']/../div/a[@danphe-grid-action='view'])[1]");
	}

	public By getRadioButtonsLocator(String radioButtonName) {
		return By.xpath("//input[@value='" + radioButtonName + "']/../span");
	}

	public By getVerificationRemarks() {
		return By.cssSelector("textarea[name='VerificationRemarks']");
	}

	/*
	 * --------------------------- Methods
	 * -------------------------------------------
	 */
	
	public void login() {
		driver.findElement(emailInput).sendKeys("admin");
		driver.findElement(passwordInput).sendKeys("pass123");
		driver.findElement(signInButton).click();

	}

	public void clickOnInventory() {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		WebElement inventoryTab = commonEvents.findElement(getInventoryLocator());
		jsExecutor.executeScript("arguments[0].scrollIntoView(true);", inventoryTab);
		commonEvents.highlight(inventoryTab);
		commonEvents.click(inventoryTab);

		WebElement internalTab = commonEvents.findElement(getInventoryPageBarFixedLocator("InternalMain"));
		commonEvents.highlight(internalTab).click(internalTab);
	}

	public void clickOnPurchaseRequest() {
		WebElement purchaseRequestTab = commonEvents.findElement(getSubNavTabLocator("Purchase Request"));
		commonEvents.highlight(purchaseRequestTab).click(purchaseRequestTab);
	}

	public void clickOnCreatePurchaseRequestButton() {
		WebElement purchaseRequestButton = commonEvents.findElement(getButtonLocatorsBytext("Create Purchase Request"));
		commonEvents.highlight(purchaseRequestButton).click(purchaseRequestButton);
	}

	public void fillTheRequiredFields(Map<String, String> data) throws InterruptedException {
		// fill mandatory details to create Purhcase Request
		commonEvents.click(getInputFieldLocator("VendorName")).sendKeys(getInputFieldLocator("VendorName"),
				data.get("vendorName"));
		commonEvents.click(getInputFieldLocator("ItemName")).sendKeys(getInputFieldLocator("ItemName"),
				data.get("itemName"));
		Thread.sleep(2000);
		commonEvents.sendKeys(getInputFieldLocator("ItemName"), Keys.ENTER);
		commonEvents.sendKeys(getLocatorById("remarks"), data.get("remarks"));
	}

	public void clickOnRequestButton() {
		WebElement requestPORequisition = commonEvents.findElement(getLocatorById("RequestPORequisition"));
		commonEvents.highlight(requestPORequisition).click(requestPORequisition);
	}

	public String verifyPurchaseRequestSuccessMsg(Map<String, String> data) {
		String successMessageText = "";
		try {

			WebElement successMessageElement = commonEvents
					.findElement(getPopUpMessageText("success", data.get("purchaseRequestCreationMessage")));
			System.out.println("Success message text : " + successMessageElement.getText());
			successMessageText = successMessageElement.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return successMessageText;
	}

	public void clickVerificationMenu() {
		try {
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			WebElement verificationTab = driver.findElement(getVerificationLocator());
			jsExecutor.executeScript("arguments[0].scrollIntoView(true);", verificationTab);
			verificationTab.click();

			// Wait for the URL to contain "Verification/Inventory"
			commonEvents.waitForUrlContains("Verification/Inventory", 10);

			WebElement inventorySubModule = commonEvents.findElement(getPageBarFixedLocator("Inventory"));
			commonEvents.highlight(inventorySubModule).click(inventorySubModule);

		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyAddedPurchaseRequestStatus(Map<String, String> data) {
		String purchaseRequestStatus = "";
		try {

			WebElement okButton = commonEvents.findElement(getOkButtonLocator());
			// Highlight and click the OK button
			commonEvents.highlight(okButton).click(okButton);

			WebElement purchaseReqElement = commonEvents
					.findElement(getPurchaseRequestStatus(data.get("vendorName"), data.get("status_1")));
			purchaseRequestStatus = purchaseReqElement.getText();

			System.out.println("purchaseRequestStatus : " + purchaseRequestStatus);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return purchaseRequestStatus;
	}

	public void clickOnViewRequestWithStatusPending() {
		WebElement viewButton = commonEvents.findElement(getPurchaseRequestViewButton("pending"));
		commonEvents.highlight(viewButton).click(viewButton);
	}

	public void approveThePurchaseRequest() {
		WebElement approveButton = commonEvents.findElement(getButtonLocatorsBytext("Approve"));
		commonEvents.highlight(approveButton).click(approveButton);
	}

	public String verifyApprovalSuccessMessage(Map<String, String> data) {
		String successMessageText = "";
		try {
			WebElement successMessageElement = commonEvents
					.findElement(getPopUpMessageText("Success", data.get("purchaseRequestApproveMessage")));
			System.out.println("Success message text : " + successMessageElement.getText() + " Expected : "
					+ data.get("purchaseRequestApproveMessage"));
			successMessageText = successMessageElement.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return successMessageText;
	}

	public void clickOnApprovedRadioButton() {
		WebElement approvedRadioButton = commonEvents.findElement(getRadioButtonsLocator("approved"));
		commonEvents.highlight(approvedRadioButton).click(approvedRadioButton);
	}

	public void clickOnRejectedRadioButton() {
		WebElement approvedRadioButton = commonEvents.findElement(getRadioButtonsLocator("rejected"));
		commonEvents.highlight(approvedRadioButton).click(approvedRadioButton);
	}

	public String verifyPurchaseRequestStatusInTable(Map<String, String> data) {
		String purchaseRequestStatus = "";
		try {
			WebElement purchaseReqElement = commonEvents
					.findElement(getPurchaseRequestStatus(data.get("vendorName"), "approved"));
			purchaseRequestStatus = purchaseReqElement.getText();
			System.out.println("purchaseRequestStatus : " + purchaseRequestStatus);

			return purchaseRequestStatus;
		} catch (Exception e) {
			throw e;
		}
	}

	public String verifyPurchaseRequestStatusInRejectedTable(Map<String, String> data) {
		String purchaseRequestStatus = "";
		try {
			WebElement purchaseReqElement = commonEvents
					.findElement(getPurchaseRequestStatus(data.get("vendorName"), "rejected"));
			purchaseRequestStatus = purchaseReqElement.getText();
			System.out.println("purchaseRequestStatus : " + purchaseRequestStatus);

			return purchaseRequestStatus;
		} catch (Exception e) {
			throw e;
		}
	}

	public void clickOnRejectAllButton() {
		WebElement rejectAllButton = commonEvents.findElement(getButtonLocatorsBytext("Reject All "));
		commonEvents.highlight(rejectAllButton).click(rejectAllButton);
	}

	public void clickOnRejectAllButtonWithRemarks(Map<String, String> verificationExpectedData) {
		commonEvents.sendKeys(getVerificationRemarks(), verificationExpectedData.get("remarks"));

		WebElement rejectAllButton = commonEvents.findElement(getButtonLocatorsBytext("Reject All "));
		commonEvents.highlight(rejectAllButton).click(rejectAllButton);
	}

	public String rejectAPurchaseRequestAndVerifyThePopUpMessage(Map<String, String> verificationExpectedData) {
		String failedMessageText = "";
		try {
			WebElement successMessageElement = commonEvents.findElement(
					getPopUpMessageText("failed", verificationExpectedData.get("remarksCompulsaryForCancellation")));
			System.out.println("Failed message text : " + successMessageElement.getText() + " Expected : "
					+ verificationExpectedData.get("remarksCompulsaryForCancellation"));
			failedMessageText = successMessageElement.getText();

			return failedMessageText;

		} catch (Exception e) {
			throw e;
		}
	}

	public void clickOnViewRequestWithStatusApproved() {
		WebElement viewButton = commonEvents.findElement(getPurchaseRequestViewButton("approved"));
		commonEvents.highlight(viewButton).click(viewButton);
	}

	public Boolean takingScreenshotOfTheCurrentPage() throws Exception {
		boolean isDisplayed = false;
		try {
			commonEvents.takeScreenshot("Verification-Purchase Request");
			isDisplayed = true;

		} catch (Exception e) {
			throw e;
		}
		return isDisplayed;
	}

}
